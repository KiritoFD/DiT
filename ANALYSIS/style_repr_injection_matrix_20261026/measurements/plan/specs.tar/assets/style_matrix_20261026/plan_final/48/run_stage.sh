#!/usr/bin/env bash
set -euo pipefail
cd /home/ds/Workspace/DiT
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
exec /home/ds/miniconda3/envs/vcp-embryo/bin/python -u -m tools.style_matrix.runtime.serial --plan assets/style_matrix_20261026/plan_final/48/plan.json "$@"
