#!/usr/bin/env bash
set -euo pipefail
cd /root/Workspace/xy/DiT
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
exec /opt/conda/envs/cu121/bin/python -u -m tools.style_matrix.runtime.serial --plan assets/style_matrix_20261026/plan_final/4090/plan.json "$@"
